function mxdisplay(varargin)

	mcdisplay(varargin{:});
